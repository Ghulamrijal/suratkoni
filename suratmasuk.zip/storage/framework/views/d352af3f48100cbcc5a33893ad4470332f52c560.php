


<?php $__env->startSection('content'); ?>
<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<!-- TABLE HOVER -->
							<div class="panel">     
								<div class="panel-heading">
									<h1 class="panel-title"><i class="lnr lnr-layers"></i> Kelola Surat Masuk </h1>
								</div>
                <!-- message error validation -->
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
								<div class="panel-body">
                <div class="row " >
                    <div class=" col-md-6">
                    <?php if($loggedIn->role_id == 1 ): ?>
                      <button type="button" class="btn btn-default" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-plus-square" ></i> Tambah data</button>
                      <?php endif; ?>
                    </div>
                    <div class="form-group input-group col-md-6">
                      <form action="/suratmasuk" method="GET">
                      <input type="search" class="form-control" id="inputPassword2" placeholder="Search..." name="search">
                      </form> 
                    </div>
                  </div>
									<table class="table table-hover">
                  <thead>
											<tr>
                        <th scope>No</th>
                        <th scope>Pengirim</th>
                        <th scope>Nomor Surat</th>
                        <th scope>Klasifikasi</th>
                        <th scope> Status </th>
                        <th scope>Tujuan Disposisi</th>
                        <th scope>Action</th>
                      </tr>
										</thead>
                    <tbody>
                     
                     
                    <?php $__currentLoopData = $suratmasuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat_masuk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                          <th scope="row"><?php echo e($loop->iteration); ?> </th>
                          <td><?php echo e($surat_masuk->nama_pengirim); ?> </td>
                          <td><?php echo e($surat_masuk->nomor_surat); ?> </td>
                          <td><?php echo e($surat_masuk->klasifikasi); ?> </td>
                          <td> <?php if($surat_masuk->disposisi != NULL): ?>
                          <a class="btn btn-success"> Disposisi </a>
                          <?php else: ?>
                          <a class="btn btn-danger"> Disposisi </a>
                                <?php endif; ?>
                          </td>
                          <td><?php echo e($surat_masuk->disposisi); ?> </td>
                          <td>
                          
                          <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">Disposisi</button> -->
                          <?php if($loggedIn->role_id == 2 ): ?>
                          <a href="" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#ModalsDisposisi-<?php echo e($surat_masuk->id); ?>">Disposisi</a>
                          <?php endif; ?>
                          <?php if($loggedIn->role_id == 3 ): ?>
                          <a href="" class="btn btn-info btn-sm" data-toggle="modal" data-target="#ModalsTL-<?php echo e($surat_masuk->id); ?>">Tindak lanjut</a>
                          <?php endif; ?>
                          <?php if($loggedIn->role_id == 1 ): ?> 
                          <a href="" class="btn btn-warning btn-sm"  data-toggle="modal" data-target="#ModalsEdit-<?php echo e($surat_masuk->id); ?>">Edit</a>
                          <a href="/suratmasuk/<?php echo e($surat_masuk->id); ?>/delete" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin ingin menghapus data?')">Delete</a>
                          <?php endif; ?>
                          </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</tbody>
                  </table>
                </div>
                <div class="position-absolute bottom-0 end-0">
                    <!-- <ul > -->
                        <?php echo e($suratmasuk->links()); ?>

                    <!-- </ul> -->
                </div>
              </div>
             
            </div>
            
          </div>
        </div>
      </div>
</div>
</div>
</div>

<!-- Modal Tambah Data -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
     <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="exampleModalLabel"> <i class="lnr lnr-layers"></i> Tambah Data Surat Masuk</h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
      </div>
      <div class="modal-body">
        <form action="/suratmasuk/create" method="POST" enctype="multipart/form-data" id="frmaddsm">
          <?php echo e(csrf_field()); ?>

          <div class="form-group">
            <label for="exampleInputNama" id="frmaddnp">Nama Pengirim</label>
              <input name="nama_pengirim"  type="text" class="form-control" id="exampleInputnama_pengirim" aria-describedby="nama_pengirimHelp">
          </div>
          <div class="form-group">
            <label for="exampleInputNama" id="frmaddns">Nomor Surat</label>
              <input name="nomor_surat"  type="text" class="form-control" id="exampleInputnomor_surat" aria-describedby="nomor_suratHelp">
          </div>
          <div class="form-group">
            <label for="exampleInputNama" id="frmaddhal">Perihal</label>
              <input name="perihal"  type="text" class="form-control" id="exampleInputperihal" aria-describedby="perihalHelp">
          </div>
          <div class="form-group">
            <label for="exampleInputNama" id="frmaddklas">Klasifikasi</label>
              <input name="klasifikasi"  type="text" class="form-control" id="exampleInputperihal" aria-describedby="klasifikasiHelp">
          </div>
          <div class="form-group">
            <label for="exampleInputNama" id="frmaddfile">Unggah File Surat(pdf)</label>
              <input type="file" class="form-control-file" id="exampleFormControlFile1" name="file">
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
        </form>     
    </div> 
  </div>
</div>
   
<?php $__currentLoopData = $suratmasuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat_masuk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Modal Edit Data -->
<div class="modal " id="ModalsEdit-<?php echo e($surat_masuk->id); ?>" tabindex="-2" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content" >
          <div class="modal-header" id="headeredit">
            <h3 class="modal-title" id="exampleModalLabel2"> <i class="lnr lnr-layers"></i> Edit Data Surat Masuk</h3>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
          </div>
          <div class="modal-body" id="bodyedit">
            <form action="/suratmasuk/<?php echo e($surat_masuk->id); ?>/update" method="POST" enctype="multipart/form-data" id="frmeditsm">
              <?php echo e(csrf_field()); ?>

              <div class="form-group">
                <label for="" id="lbleditnama">Nama Pengirim</label>
                  <input name="editnamapengirim"  type="text" class="form-control" id="editnamapengirim" value="<?php echo e($surat_masuk->nama_pengirim); ?>">
              </div>
              <div class="form-group">
                <label for="" id="lbleditns">Nomor Surat</label>
                  <input name="editnomorsurat"  type="text" class="form-control" id="editnomorsurat" value="<?php echo e($surat_masuk->nomor_surat); ?>">
              </div>
              <div class="form-group">
                <label for="" id="lbledithal">Perihal</label>
                  <input name="editperihal"  type="text" class="form-control" id="editperihal" value="<?php echo e($surat_masuk->perihal); ?>">
              </div>
              <div class="form-group">
                <label for="" id="lbleditklas">Klasifikasi</label>
                  <input name="editklas"  type="text" class="form-control" id="editklas" value="<?php echo e($surat_masuk->klasifikasi); ?>">
              </div>
              <div class="form-group">
                <label for="" id="lbleditfile">Unggah File Surat(pdf)</label>
                  <input type="file" class="form-control-file" id="editfile" name="editfile">
                    <file src="<?php echo e(asset('admin/assets/file/' . $surat_masuk->file)); ?>" alt="file" >
              </div>
          </div>
          <div class="modal-footer" id="footeredit">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
          </form> 
    </div> 
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $suratmasuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat_masuk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Modal Disposisi Data -->
<div class="modal fade" id="ModalsDisposisi-<?php echo e($surat_masuk->id); ?>" tabindex="-3" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content" >
          <div class="modal-header" id="headerdispo">
            <h3 class="modal-title" id="exampleModalLabel3"> <i class="lnr lnr-layers"></i> Disposisi </h3>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
          </div>
          <div class="modal-body" id="bodydispo">
            <form action="/suratmasuk/<?php echo e($surat_masuk->id); ?>/disposisi" method="POST" enctype="multipart/form-data" id="frmdisposm">
              <?php echo e(csrf_field()); ?>

              <div class="form-group">
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="disposisi" id="exampleRadios1" value="Kepala Seksi Tata Kelola dan Pemberdayaan Teknologi Informatika" checked>
                    <label class="form-check-label" for="exampleRadios1">
                      Kepala Seksi Tata Kelola dan Pemberdayaan Teknologi Informatika
                    </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="disposisi" id="exampleRadios2" value="Kepala Seksi Pengembangan Aplikasi dan Sumber Daya Manusia" checked>
                    <label class="form-check-label" for="exampleRadios2">
                      Kepala Seksi Pengembangan Aplikasi dan Sumber Daya Manusia
                    </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="disposisi" id="exampleRadios3" value="Kepala Seksi Jaringan Infrastruktur Teknologi Informasi, Persandian dan Keamanan Informasi" checked>
                    <label class="form-check-label" for="exampleRadios2">
                      Kepala Seksi Jaringan Infrastruktur Teknologi Informasi, Persandian dan Keamanan Informasi
                    </label>
                </div>
              </div>
              <div class="form-group">
                <label for="" id="lbldispons">Keterangan Disposisi</label>
                  <textarea name="updatedispoket"  type="text" class="form-control" id="updatedispoket" ><?php echo "{$surat_masuk->ket_disposisi}";?></textarea>
              </div>
              
          </div>
          <div class="modal-footer" id="footeredit">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
          </form> 
    </div> 
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__currentLoopData = $suratmasuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat_masuk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<!-- Modal Ket Tindak Lanjut Data -->
<div class="modal fade" id="ModalsTL-<?php echo e($surat_masuk->id); ?>" tabindex="-4" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content" >
          <div class="modal-header" id="headertl">
            <h3 class="modal-title" id="exampleModalLabel4"> <i class="lnr lnr-layers"></i> Keterangan Tindak Lanjut </h3>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
          </div>
          <div class="modal-body" id="bodytl">
            <form action="/suratmasuk/<?php echo e($surat_masuk->id); ?>/tindaklanjut" method="POST" enctype="multipart/form-data" id="frmtlsm">
              <?php echo e(csrf_field()); ?>

              <div class="form-group">
                <label for="" id="lblkettl">Keterangan Tindak Lanjut</label>
                  <textarea name="updatekettl"  type="text" class="form-control" id="updatekettl" row="5px" ><?php echo "{$surat_masuk->tindak_lanjut}";?></textarea>
              </div>
              
          </div>
          <div class="modal-footer" id="footertl">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
          </form> 
    </div> 
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PKL&TA\PKL\PROJECT\suratmasuk\resources\views/suratmasuk/index.blade.php ENDPATH**/ ?>