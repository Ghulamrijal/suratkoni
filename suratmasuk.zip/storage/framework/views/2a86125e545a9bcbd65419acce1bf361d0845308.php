


<?php $__env->startSection('content'); ?>
<div class="main">
<div class="main-content">
<div class="container-fluid">
<div class="panel panel-headline">
<div id="home">
    <P><h2><center> SELAMAT DATANG DI HOME SISTEM</center></h2></P>
    <P><h2><center> PENGELOLA SURAT MASUK BIDANG</center></h2></P>
    <P><h2><center> INFORMATIKA DAN PERSANDIAN</center></h2></P>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Joki_nadia\resources\views/home/index.blade.php ENDPATH**/ ?>