

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
     <?php if(session('sukses')): ?>
    <div class="alert alert-success" role="alert">
    <?php echo e(session('sukses')); ?>

    </div>
</div>
    <?php endif; ?>
<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
     
      <div class="panel">
		<div class="panel-heading">
			<h3 class="panel-title"><i class="lnr lnr-layers"></i> Tindak Lanjut</h3>
		</div>
	  <div class="panel-body">
      <form action="/suratmasuk/<?php echo e($suratmasuk->id); ?>/update" method="POST">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
                                <div class="form-group">
                                  <label for="exampleFormControlTextarea1">Keterangan tindak lanjut</label>
                                  <textarea name="tindak_lanjut"  type="text" class="form-control" id="exampleFormControlTextarea1" row="5" aria-describedby="tindak_lanjutHelp"><?php echo "{$suratmasuk->tindak_lanjut}";?></textarea>
                                </div>
                                
  
  

    <button type="submit" class="btn btn-primary">Simpan</button>
  
</form>
								</div>
							</div>
    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Joki_nadia\resources\views/suratmasuk/tindaklanjut.blade.php ENDPATH**/ ?>