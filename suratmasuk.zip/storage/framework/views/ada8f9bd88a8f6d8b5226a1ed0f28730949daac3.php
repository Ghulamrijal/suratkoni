

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
     <?php if(session('sukses')): ?>
    <div class="alert alert-success" role="alert">
    <?php echo e(session('sukses')); ?>

    </div>
</div>
    <?php endif; ?>
<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
     
      <div class="panel">
		<div class="panel-heading">
			<h3 class="panel-title"> <i class="lnr lnr-layers"></i> Disposisi</h3>
		</div>
	  <div class="panel-body">
      <form action="/suratmasuk/<?php echo e($suratmasuk->id); ?>/update" method="POST">
        <?php echo e(csrf_field()); ?>

                                <!-- <div class="form-group">
                                  <label for="exampleInputNama">Nama Pengirim</label>
                                   <input name="nama_pengirim"  type="text" class="form-control" id="exampleInputnama_pengirim" aria-describedby="nama_pengirimHelp" value="<?php echo e($suratmasuk->nama_pengirim); ?>">
                                </div>
                                <div class="form-group">
                                  <label for="exampleInputNama">Nomor Surat</label>
                                  <input name="nomor_surat"  type="text" class="form-control" id="exampleInputnomor_surat" aria-describedby="nomor_suratHelp" value="<?php echo e($suratmasuk->nomor_surat); ?>"> 
                                </div>
                                <div class="form-group">
                                  <label for="exampleInputNama">Perihal</label>
                                  <input name="perihal"  type="text" class="form-control" id="exampleInputperihal" aria-describedby="perihalHelp" value="<?php echo e($suratmasuk->perihal); ?>">
                                </div>
                                <div class="form-group">
                                  <label for="exampleInputNama">Klasifikasi</label>
                                  <input name="klasifikasi"  type="text" class="form-control" id="exampleInputperihal" aria-describedby="klasifikasiHelp" value="<?php echo e($suratmasuk->klasifikasi); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputNama">Unggah File Surat (pdf)</label>
                                    <input type="file" class="form-control-file" id="exampleFormControlFile1" name="file">
                                    <file src="<?php echo e(asset('admin/assets/file/' . $suratmasuk->file)); ?>" alt="file" >
                                </div> -->
                                <div class="form-group">
                                   <div class="form-check">
                                      <input class="form-check-input" type="radio" name="disposisi" id="exampleRadios1" value="Kepala Seksi Tata Kelola dan Pemberdayaan Teknologi Informatika" checked>
                                      <label class="form-check-label" for="exampleRadios1">
                                        Kepala Seksi Tata Kelola dan Pemberdayaan Teknologi Informatika
                                      </label>
                                    </div>
                                    <div class="form-check">
                                      <input class="form-check-input" type="radio" name="disposisi" id="exampleRadios2" value="Kepala Seksi Pengembangan Aplikasi dan Sumber Daya Manusia" checked>
                                      <label class="form-check-label" for="exampleRadios2">
                                        Kepala Seksi Pengembangan Aplikasi dan Sumber Daya Manusia
                                      </label>
                                    </div>
                                    <div class="form-check">
                                      <input class="form-check-input" type="radio" name="disposisi" id="exampleRadios3" value="Kepala Seksi Jaringan Infrastruktur Teknologi Informasi, Persandian dan Keamanan Informasi" checked>
                                      <label class="form-check-label" for="exampleRadios2">
                                        Kepala Seksi Jaringan Infrastruktur Teknologi Informasi, Persandian dan Keamanan Informasi
                                      </label>
                                    </div>
                                </div>
                                <div class="form-group">
                                  <label for="exampleFormControlTextarea1">Keterangan Disposisi</label>
                                  <textarea name="ket_disposisi"  type="text" class="form-control" id="exampleFormControlTextarea1" row="3" aria-describedby="ket_disposisiHelp"></textarea>
                                </div>
                                
  
  

    <button type="submit" class="btn btn-primary">Simpan</button>
  
</form>
								</div>
							</div>
    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Joki_nadia\resources\views/suratmasuk/disposisi.blade.php ENDPATH**/ ?>