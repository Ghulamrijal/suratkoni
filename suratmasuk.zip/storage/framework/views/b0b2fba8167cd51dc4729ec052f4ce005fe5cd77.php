

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
     <?php if(session('sukses')): ?>
    <div class="alert alert-success" role="alert">
    <?php echo e(session('sukses')); ?>

    </div>
</div>
    <?php endif; ?>
<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
     
      <div class="panel">
		<div class="panel-heading">
			<h3 class="panel-title"><i class="lnr lnr-layers"></i> Edit Klasifikasi</h3>
		</div>
	  <div class="panel-body">
        <form action="/klasifikasi/<?php echo e($klasifikasi->id); ?>/update" method="POST">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
              <label for="exampleInputNama">Nama</label>
              <input name="nama"  type="text" class="form-control" id="exampleInputNama" aria-describedby="namaHelp" value="<?php echo e($klasifikasi->nama); ?>">
            </div>
            <div class="form-group">
              <label for="exampleInputKode">Kode</label>
              <input name="kode"  type="text" class="form-control" id="examplekode" aria-describedby="kode" value="<?php echo e($klasifikasi->kode); ?>">
            </div>
            <div class="form-group">
    <label for="exampleInputUraian">Uraian</label>
    <textarea name="uraian" type="text" class="form-control" id="exampleInputUraian" aria-describedby="uraianHelp" row="3" ><?php echo "{$klasifikasi->uraian}";?></textarea>
  </div>
  
  

    <button type="submit" class="btn btn-warning">Update</button>
  
</form>
								</div>
							</div>
    </div>
  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Joki_nadia\resources\views/klasifikasi/edit.blade.php ENDPATH**/ ?>