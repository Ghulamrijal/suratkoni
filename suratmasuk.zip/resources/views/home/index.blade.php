@extends('layouts.master')


@section('content')
<div class="main">
<div class="main-content">
<div class="container-fluid">
<div class="panel panel-headline">
<div id="home">
    <br><br><br><br><br><br><br><br>
    <P><h1><center> SELAMAT DATANG DI HOME SISTEM</center></h1></P>
    <P><h1><center> PENGELOLA SURAT MASUK BIDANG</center></h1></P>
    <P><h1><center> INFORMATIKA DAN PERSANDIAN</center></h1></P>
    <br><br><br><br><br><br><br><br>
</div>
</div>
</div>
</div>
</div>
@endsection